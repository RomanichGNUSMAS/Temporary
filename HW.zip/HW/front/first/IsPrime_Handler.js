const isPrime = (() => {
    const cache = {1:false,2:true};
    return (n) => {
        if(cache[n]) return cache[n];

        for(let i = 2; i <= n / 2; ++i) {
            if(n % i == 0) return cache[n] = false;
        }
    
        cache[n] = true;
        return true;
    }
})();
console.log(isPrime(7))