
function curry(callback) {
    const length = callback.length;
    return function handler(...args) {
        if(args.length >= length) return callback(...args);
        else return handler.bind(this,...args)
    }
}

const sum = (a,b,c) => a + b + c;
const fn = curry(sum);

console.log(fn(1,2,3));
console.log(fn(1)(2)(3));