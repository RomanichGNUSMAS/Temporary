function HOF(callback) {
    return function fn(...args) {
        fn.history ??= [];
        const res = callback(...args);
        fn.history.push({args:[...args], out:res});
        return res;
    }
}

const square = x => x * x;
const sqr = HOF(square);
sqr(2)
sqr(6)
sqr(4)

